package com.efunhub.grokisan.interfaces;

public interface RemoveCart {

    public void removeCart();

}
