package com.efunhub.grokisan.interfaces;

public interface UpdateItemPrice {

    public void onItemCountChanged(int size,int price);
}
