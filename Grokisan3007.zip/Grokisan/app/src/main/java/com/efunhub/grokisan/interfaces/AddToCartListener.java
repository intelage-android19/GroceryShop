package com.efunhub.grokisan.interfaces;

public interface AddToCartListener {

    public void addToCart();
}
