package com.efunhub.grokisan.interfaces;

/**
 * Created by Admin on 06-12-2018.
 */

public interface NoInternetListener {
    void availConnection(boolean connection);
}
