package com.efunhub.grokisan.fragments;


import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.IntentFilter;
import android.databinding.DataBindingUtil;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.VolleyError;
import com.efunhub.grokisan.R;
import com.efunhub.grokisan.databinding.FragmentProfileBinding;
import com.efunhub.grokisan.interfaces.IResult;
import com.efunhub.grokisan.interfaces.NoInternetListener;
import com.efunhub.grokisan.model.ProfileBaseModel;
import com.efunhub.grokisan.model.ProfileUpdateBaseModel;
import com.efunhub.grokisan.model.ProfileUpdateModel;
import com.efunhub.grokisan.model.Profilemodel;
import com.efunhub.grokisan.utility.CheckConnectivity;
import com.efunhub.grokisan.utility.SessionManager;
import com.efunhub.grokisan.utility.ToastClass;
import com.efunhub.grokisan.utility.VolleyService;
import com.efunhub.grokisan.validator.InputValidatorHelper;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;

import static com.efunhub.grokisan.utility.ConstantVariables.UPDATE_USER_PROFILE;
import static com.efunhub.grokisan.utility.ConstantVariables.USER_PROFILE;
import static com.efunhub.grokisan.utility.SessionManager.KEY_ID;


/**
 * A simple {@link Fragment} subclass.
 */
public class ProfileFragment extends BaseFragment {

    private FragmentProfileBinding mBinder;
    private IResult mResultCallback;
    private VolleyService mVollyService;
    private ToastClass toastClass;
    private ProgressDialog progressDialog;
    private CheckConnectivity checkConnectivity;
    private boolean connectivityStatus = true;
    private String ProfileURL = "profile_customer.php";
    private String UpdateProfileURL = "update_profile_customer.php";
    Dialog dialog;


    Profilemodel profilemodel;
    ProfileBaseModel profileBaseModel;
    ProfileUpdateModel profileUpdateModel;
    ProfileUpdateBaseModel profileUpdateBaseModel;

    TextView tvProfileName;

    EditText dialogName, dialogContact, dialogEmail, dialogAddress;

    private SessionManager sessionManager;

    private String userId;

    public ProfileFragment() {
        // Required empty public constructor
    }

    public static ProfileFragment newInstance() {

        ProfileFragment profileFragment = new ProfileFragment();
        return profileFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mBinder = DataBindingUtil.inflate(inflater, R.layout.fragment_profile, container, false);

        setHasOptionsMenu(true);

        setUpToolbarWithoutTitle(mBinder.toolbar.toolbar, true);

        sessionManager = new SessionManager(getActivity());

        HashMap<String, String> userInfo = sessionManager.getUserDetails();

        userId = userInfo.get(KEY_ID);

        tvProfileName = mBinder.tvProfileFullName;

        loadProfile();


        mBinder.btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialog();
            }

        });

        toastClass = new ToastClass();
        progressDialog = ProgressDialog.show(getContext(), "GroKisan",
                "Please wait while loading..", false, false);

        return mBinder.getRoot();

    }


    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        MenuItem item = menu.findItem(R.id.action_cart);
        if (item != null)
            item.setVisible(false);
    }

    private void loadProfile() {

        initVolleyCallback();

        HashMap<String, String> param = new HashMap<>();
        param.put("cust_id", userId);//"5d2577d462c29"

        mVollyService = new VolleyService(mResultCallback, getContext());
        mVollyService.postDataVolleyParameters(USER_PROFILE,
                this.getResources().getString(R.string.base_url) + ProfileURL, param);

    }

    private void updateProfile() {

        final String fullName = dialogName.getText().toString();
        final String email = dialogEmail.getText().toString();
        final String contact = dialogContact.getText().toString();
        final String address = dialogAddress.getText().toString();

        initVolleyCallback();

        mVollyService = new VolleyService(mResultCallback, getContext());

        HashMap<String, String> params = new HashMap<>();
        params.put("cust_id", userId);//"5d2577d462c29"
        params.put("name", fullName);
        params.put("email", email);
        params.put("contact", contact);
        params.put("address", address);

        mVollyService.postDataVolleyParameters(UPDATE_USER_PROFILE,
                this.getResources().getString(R.string.base_url) + UpdateProfileURL, params);
    }

    private boolean checkValidation() {

        InputValidatorHelper inputValidatorHelper = new InputValidatorHelper();

        if (inputValidatorHelper.isNullOrEmpty(dialogName.getText().toString())) {
            dialogName.setError("Please enter full name");
            return false;

        } else if (inputValidatorHelper.isNullOrEmpty(dialogContact.getText().toString())) {
            dialogContact.setError("Please enter mobile number");
            return false;

        } else if (!inputValidatorHelper.isValidMobile(dialogContact.getText().toString())) {
            dialogContact.setError("Please enter valid mobile number");
            return false;

        } else if (!inputValidatorHelper.isValidMobileNoLength(dialogContact.getText().toString())) {
            dialogContact.setError("Please enter valid mobile number");
            return false;

        } else if (inputValidatorHelper.isNullOrEmpty(dialogEmail.getText().toString())) {
            dialogEmail.setError("Please enter email id");
            return false;

        } else if (!inputValidatorHelper.isValidEmail(dialogEmail.getText().toString())) {
            dialogEmail.setError("Please enter valid email id");
            return false;

        }
        return true;
    }

    private void initVolleyCallback() {
        try {
            mResultCallback = new IResult() {
                @Override
                public void notifySuccess(int requestId, String response) {

                    switch (requestId) {

                        case USER_PROFILE:
                            try {
                                JSONObject jsonObject = new JSONObject(response);

                                int status = jsonObject.getInt("status");

                                if (status == 1) {

                                    //  progressDialog.cancel();

                                    JSONArray jsonArray = jsonObject.getJSONArray("allprofile");

                                    Gson gson = new Gson();
                                    profileBaseModel = gson.fromJson(
                                            response, ProfileBaseModel.class);

                                    List<Profilemodel> profilemodelList = profileBaseModel.getAllprofile();
                                    profilemodel = profilemodelList.get(0);
                                    mBinder.tvProfileFullName.setText(profilemodelList.get(0).getName());
                                    mBinder.tvPrfileMobileNumber.setText(profilemodelList.get(0).getContact());
                                    mBinder.tvProfileEmail.setText(profilemodelList.get(0).getEmail());
                                    mBinder.tvProfileAddress.setText(profilemodelList.get(0).getAddress());


                                } else {
                                    progressDialog.cancel();
                                    toastClass.makeToast(getContext(), "Sorry an account does not exist");
                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            progressDialog.dismiss();
                            break;

                        case UPDATE_USER_PROFILE:

                            try {
                                JSONObject jsonObject = new JSONObject(response);

                                int status = jsonObject.getInt("status");
                                if (status == 0) {
                                    progressDialog.cancel();
                                    toastClass.makeToast(getContext(), "Please try again.");

                                } else if (status == 1) {
                                    progressDialog.cancel();
                                    toastClass.makeToast(getContext(), " Updated Sucessfully");
                                    loadProfile();

                                } else if (status == 2) {
                                    progressDialog.cancel();
                                    toastClass.makeToast(getContext(), "Enter Valid Contact");
                                } else if (status == 3) {
                                    progressDialog.cancel();
                                    toastClass.makeToast(getContext(), "Check Email Format");
                                }

                            } catch (JSONException e) {
                                progressDialog.cancel();
                                e.printStackTrace();
                            }
                            break;


                    }

                }

                @Override
                public void notifyError(int requestId, VolleyError error) {
                    Log.v("Volley requestid ", String.valueOf(requestId));
                    Log.v("Volley Error", String.valueOf(error));
                }
            };
        } catch (Exception ex) {

            Log.d("ProfileActivity", "initVolleyCallback: " + ex);
        }

    }


    @Override
    public void onResume() {
        super.onResume();

        //Check connectivity
        checkConnectivity = new CheckConnectivity(getContext(), new NoInternetListener() {
            @Override
            public void availConnection(boolean connection) {
                if (connection) {
                    connectivityStatus = true;
                } else {
                    connectivityStatus = false;
                }
            }
        });
        IntentFilter intentFilter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        getContext().registerReceiver(checkConnectivity, intentFilter);
    }

    @Override
    public void onPause() {
        super.onPause();
        /*UnRegister receiver for connectivity*/
        getContext().unregisterReceiver(checkConnectivity);
    }


    void dialog() {

        dialog = new Dialog(getContext());
        dialog.setContentView(R.layout.update_profile);
        //dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.GREEN));
        dialog.setCanceledOnTouchOutside(true);

        ImageView ivCancle = dialog.findViewById(R.id.ivClose);
        Button btnUpdateProfile = dialog.findViewById(R.id.btnUpdateProfile);

        dialogName = dialog.findViewById(R.id.cetName);
        dialogContact = dialog.findViewById(R.id.cetContact);
        dialogEmail = dialog.findViewById(R.id.cetEmail);
        dialogAddress = dialog.findViewById(R.id.cetAddress);

        dialogName.setText(profilemodel.getName());
        dialogContact.setText(profilemodel.getContact());
        dialogEmail.setText(profilemodel.getEmail());
        dialogAddress.setText(profilemodel.getAddress());

        dialog.show();

        ivCancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.cancel();
            }
        });

        btnUpdateProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (checkValidation()) {

                    updateProfile();

                    dialog.cancel();

                }

            }
        });


    }


}

