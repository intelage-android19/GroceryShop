package com.efunhub.grokisan.interfaces;

public interface SmsListener {

    public void messageReceived(String messageText);
}
