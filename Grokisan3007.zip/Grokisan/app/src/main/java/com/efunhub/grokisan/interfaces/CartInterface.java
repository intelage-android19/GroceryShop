package com.efunhub.grokisan.interfaces;

public interface CartInterface {

    void addToCart();

}
