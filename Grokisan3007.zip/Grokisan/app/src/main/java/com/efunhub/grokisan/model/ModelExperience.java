package com.efunhub.grokisan.model;

public class ModelExperience {


    private int expId;
    private int expImage;
    private String expTitle;
    private String expDescription;

    public int getExpId() {
        return expId;
    }

    public void setExpId(int expId) {
        this.expId = expId;
    }

    public int getExpImage() {
        return expImage;
    }

    public void setExpImage(int expImage) {
        this.expImage = expImage;
    }

    public String getExpTitle() {
        return expTitle;
    }

    public void setExpTitle(String expTitle) {
        this.expTitle = expTitle;
    }

    public String getExpDescription() {
        return expDescription;
    }

    public void setExpDescription(String expDescription) {
        this.expDescription = expDescription;
    }
}
