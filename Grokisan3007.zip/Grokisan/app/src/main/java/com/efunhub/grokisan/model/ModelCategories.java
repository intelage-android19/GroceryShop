package com.efunhub.grokisan.model;

public class ModelCategories {
    private int fruitid;
    private int fruitImage;
    private String fruitName;
    private String fruitQuantity;
    private String fruitPrice;
    private String fruitOfferPrice;


    private int vegitableid;
    private int vegitableImage;
    private String vegitableName;
    private int vegitableQuantity;
    private String vegitablePrice;
    private String vegitableOfferPrice;


    private int grainid;
    private int grainImage;
    private String grainName;
    private String grainQuantity;
    private String grainPrice;
    private String grainOfferPrice;



    public int getFruitid() {
        return fruitid;
    }

    public void setFruitid(int fruitid) {
        this.fruitid = fruitid;
    }

    public int getFruitImage() {
        return fruitImage;
    }

    public void setFruitImage(int fruitImage) {
        this.fruitImage = fruitImage;
    }

    public String getFruitName() {
        return fruitName;
    }

    public void setFruitName(String fruitName) {
        this.fruitName = fruitName;
    }

    public String getFruitQuantity() {
        return fruitQuantity;
    }

    public void setFruitQuantity(String fruitQuantity) {
        this.fruitQuantity = fruitQuantity;
    }

    public String getFruitPrice() {
        return fruitPrice;
    }

    public void setFruitPrice(String fruitPrice) {
        this.fruitPrice = fruitPrice;
    }

    public String getFruitOfferPrice() {
        return fruitOfferPrice;
    }

    public void setFruitOfferPrice(String fruitOfferPrice) {
        this.fruitOfferPrice = fruitOfferPrice;
    }




    public int getVegitableid() {
        return vegitableid;
    }

    public void setVegitableid(int vegitableid) {
        this.vegitableid = vegitableid;
    }

    public int getVegitableImage() {
        return vegitableImage;
    }

    public void setVegitableImage(int vegitableImage) {
        this.vegitableImage = vegitableImage;
    }

    public String getVegitableName() {
        return vegitableName;
    }

    public void setVegitableName(String vegitableName) {
        this.vegitableName = vegitableName;
    }

    public int getVegitableQuantity() {
        return vegitableQuantity;
    }

    public void setVegitableQuantity(int vegitableQuantity) {
        this.vegitableQuantity = vegitableQuantity;
    }

    public String getVegitablePrice() {
        return vegitablePrice;
    }

    public void setVegitablePrice(String vegitablePrice) {
        this.vegitablePrice = vegitablePrice;
    }

    public String getVegitableOfferPrice() {
        return vegitableOfferPrice;
    }

    public void setVegitableOfferPrice(String vegitableOfferPrice) {
        this.vegitableOfferPrice = vegitableOfferPrice;
    }




    public int getGrainid() {
        return grainid;
    }

    public void setGrainid(int grainid) {
        this.grainid = grainid;
    }

    public int getGrainImage() {
        return grainImage;
    }

    public void setGrainImage(int grainImage) {
        this.grainImage = grainImage;
    }

    public String getGrainName() {
        return grainName;
    }

    public void setGrainName(String grainName) {
        this.grainName = grainName;
    }

    public String getGrainQuantity() {
        return grainQuantity;
    }

    public void setGrainQuantity(String grainQuantity) {
        this.grainQuantity = grainQuantity;
    }

    public String getGrainPrice() {
        return grainPrice;
    }

    public void setGrainPrice(String grainPrice) {
        this.grainPrice = grainPrice;
    }

    public String getGrainOfferPrice() {
        return grainOfferPrice;
    }

    public void setGrainOfferPrice(String grainOfferPrice) {
        this.grainOfferPrice = grainOfferPrice;
    }

}
